.onAttach <- function(...) {
    packageStartupMessage("\nFor details see https://stattarget.github.io.\n")
    # statTarget::statTargetGUI()
}

## ----style, echo = FALSE, results = 'asis'-------------------------------
BiocStyle::markdown()

## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----sessionInfo, eval = TRUE, echo = TRUE-------------------------------
sessionInfo()

